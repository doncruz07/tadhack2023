import { db } from './firebase-config.js';
import { onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.18.0/firebase-auth.js';
import { getDatabase, ref, onValue, push, get, update } from 'https://www.gstatic.com/firebasejs/9.18.0/firebase-database.js';

const dbRef = getDatabase();

document.getElementById("BotonSalir").addEventListener("click", function() {
    // Redirige a la página HTML deseada
    window.location.href = "index.html";
});

document.getElementById("Botonvolver").addEventListener("click", function() {
    // Redirige a la página HTML deseada
    window.location.href = "TadHack.html";
});
 
 
// Obtener una referencia a la lista de chats del operador
const operadorChatsRef = ref(dbRef, 'DatosHumedad');
let fechas = [];
let valores = [];
 
const DatosTemp = ref(dbRef,'DatosTemperatura')

// Obtener los chats una vez
get(operadorChatsRef).then((snapshot) => {
  if (snapshot.exists()) {
    snapshot.forEach((chatSnapshot) => {
      const chatData = chatSnapshot.val();
      const chatID = chatSnapshot.key;
      console.log(chatData);
      const fecha = chatData.fecha;
      const valor = chatData.valor;
      fechas.push(fecha);
      valores.push(valor);
    });

      // Crear un contexto de lienzo para la gráfica
      const ctx = document.getElementById('humedadChart').getContext('2d');

      // Crear un objeto de configuración para la gráfica
      const chartData = {
        type: 'line', // Tipo de gráfica
        data: {
          labels: fechas, // Fechas en el eje horizontal
          datasets: [{
            label: 'Humedad', // Etiqueta de la serie de datos
            data: valores, // Valores en el eje vertical
            borderColor: 'blue', // Color de la línea
            fill: false, // No rellenar el área bajo la línea
          }]
        }
      };

      // Crear la gráfica
      const myChart = new Chart(ctx, chartData);
    
}
});



///Desde temperatura
// Obtener los chats una vez
get(DatosTemp).then((snapshot) => {
    if (snapshot.exists()) {
      snapshot.forEach((chatSnapshot) => {
        const chatData = chatSnapshot.val();
        const chatID = chatSnapshot.key;
        console.log(chatData);
        const fecha = chatData.fecha;
        const valor = chatData.valor;
        fechas.push(fecha);
        valores.push(valor);
      });
  
        // Crear un contexto de lienzo para la gráfica
        const ctx = document.getElementById('temperaturaChart').getContext('2d');
  
        // Crear un objeto de configuración para la gráfica
        const chartData = {
          type: 'line', // Tipo de gráfica
          data: {
            labels: fechas, // Fechas en el eje horizontal
            datasets: [{
              label: 'Temperatura', // Etiqueta de la serie de datos
              data: valores, // Valores en el eje vertical
              borderColor: 'blue', // Color de la línea
              fill: false, // No rellenar el área bajo la línea
            }]
          }
        };
  
        // Crear la gráfica
        const myChart = new Chart(ctx, chartData);
      
  }
  });
