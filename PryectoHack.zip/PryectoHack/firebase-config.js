
 // Import the functions you need from the SDKs you need
 import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
 import {getAuth }        from "https://www.gstatic.com/firebasejs/9.18.0/firebase-auth.js" 
          
 import { getFirestore}   from "https://www.gstatic.com/firebasejs/9.18.0/firebase-firestore.js"
 
 // TODO: Add SDKs for Firebase products that you want to use
 // https://firebase.google.com/docs/web/setup#available-libraries
   
 // Your web app's Firebase configuration
 const firebaseConfig = {
  apiKey: "AIzaSyAUVX_vNJRNLQTfe-2KZmguJ58Fop8R5iM",
  authDomain: "hack-2023-31409.firebaseapp.com",
  projectId: "hack-2023-31409",
  storageBucket: "hack-2023-31409.appspot.com",
  messagingSenderId: "752629412901",
  appId: "1:752629412901:web:b1738dad1e9b419d56bbcc",
  measurementId: "G-JCVNE5700S"
};
    
 // Initialize Firebase
 export const app  = initializeApp(firebaseConfig);
 export const db   = getFirestore(app);
 export const auth = getAuth(app);    


// import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
// import {getAuth }        from "https://www.gstatic.com/firebasejs/9.18.0/firebase-auth.js";
// import { getFirestore}   from "https://www.gstatic.com/firebasejs/9.18.0/firebase-firestore.js"
// import { getDatabase }  from "https://www.gstatic.com/firebasejs/9.6.0/firebase-database.js"
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries 
 
// // Your web app's Fireba  se configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyBcLNBxXxpMiEctzYgIGV7HdCUiJL_6tOE",
//   authDomain: "tadhack2023-8c0d5.firebaseapp.com",
//   databaseURL: "https://tadhack2023-8c0d5-default-rtdb.firebaseio.com",
//   projectId: "tadhack2023-8c0d5",
//   storageBucket: "tadhack2023-8c0d5.appspot.com",
//   messagingSenderId: "889217534992",
//   appId: "1:889217534992:web:385198b45af89d7ae14e95",
//   measurementId: "G-1Z67DJR3BP"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// export const db   = getFirestore(app);
// export const auth = getAuth(app);
// export const database = getDatabase(app);
